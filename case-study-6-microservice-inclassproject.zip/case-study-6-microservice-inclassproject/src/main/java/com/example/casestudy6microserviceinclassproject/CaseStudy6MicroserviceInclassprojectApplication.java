package com.example.casestudy6microserviceinclassproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaseStudy6MicroserviceInclassprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaseStudy6MicroserviceInclassprojectApplication.class, args);
	}

}

