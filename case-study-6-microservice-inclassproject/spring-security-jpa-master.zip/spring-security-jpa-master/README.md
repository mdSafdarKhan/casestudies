# spring-security-jpa
How to implement spring security connecting with database
